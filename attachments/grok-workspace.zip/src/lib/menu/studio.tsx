import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";
import { Navigate, useRouterState } from "@tanstack/react-router";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { getMyStudio } from "./owner";
import type { FnErr, StudioSnapshot } from "./types";
import { LoadingState, ErrorState } from "@/components/state-panel";

type StudioCtx = {
  snapshot: StudioSnapshot;
  reload: () => Promise<void>;
  setSnapshot: (next: StudioSnapshot) => void;
};

const Ctx = createContext<StudioCtx | null>(null);

export function useStudio() {
  const value = useContext(Ctx);
  if (!value) throw new Error("Studio context missing");
  return value;
}

export function StudioGate({ children }: { children: ReactNode }) {
  const { user, isPending } = useCurrentUserState();
  const path = useRouterState({ select: (s) => s.location.pathname });
  const [state, setState] = useState<
    | { status: "loading" }
    | { status: "error"; error: FnErr }
    | { status: "empty" }
    | { status: "ok"; snapshot: StudioSnapshot }
  >({ status: "loading" });

  const load = useCallback(async () => {
    setState({ status: "loading" });
    try {
      const result = await getMyStudio();
      if (!result.ok) {
        setState({ status: "error", error: result });
        return;
      }
      if (!("tenant" in result.data) || result.data.tenant == null) {
        setState({ status: "empty" });
        return;
      }
      setState({ status: "ok", snapshot: result.data as StudioSnapshot });
    } catch (err) {
      setState({
        status: "error",
        error: {
          ok: false,
          code: "unavailable",
          error: err instanceof Error ? err.message : "تعذر تحميل الاستوديو",
        },
      });
    }
  }, []);

  useEffect(() => {
    if (!user) return;
    void load();
  }, [user, load]);

  if (isPending) return <LoadingState />;
  if (!user) return <RedirectToSignIn />;
  if (state.status === "loading") return <LoadingState />;
  if (state.status === "error") {
    return <ErrorState message={state.error.error} onRetry={() => void load()} />;
  }
  if (state.status === "empty") {
    if (path.startsWith("/onboarding")) return <>{children}</>;
    return <Navigate to="/onboarding" />;
  }
  return (
    <Ctx.Provider
      value={{
        snapshot: state.snapshot,
        reload: load,
        setSnapshot: (next) => setState({ status: "ok", snapshot: next }),
      }}
    >
      {children}
    </Ctx.Provider>
  );
}
